﻿namespace DataBase_Project
{
    partial class UserControl_College
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.college_textBox_Phone = new System.Windows.Forms.TextBox();
            this.college_textBox_Location = new System.Windows.Forms.TextBox();
            this.userBtn_Reset = new System.Windows.Forms.Button();
            this.college_textBox_Email = new System.Windows.Forms.TextBox();
            this.college_textBox_Name = new System.Windows.Forms.TextBox();
            this.college_textBox_ID = new System.Windows.Forms.TextBox();
            this.college_Email = new System.Windows.Forms.Label();
            this.college_Phone = new System.Windows.Forms.Label();
            this.college_Location = new System.Windows.Forms.Label();
            this.college_Name = new System.Windows.Forms.Label();
            this.college_ID = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // college_textBox_Phone
            // 
            this.college_textBox_Phone.Location = new System.Drawing.Point(137, 129);
            this.college_textBox_Phone.Name = "college_textBox_Phone";
            this.college_textBox_Phone.Size = new System.Drawing.Size(228, 22);
            this.college_textBox_Phone.TabIndex = 72;
            // 
            // college_textBox_Location
            // 
            this.college_textBox_Location.Location = new System.Drawing.Point(137, 93);
            this.college_textBox_Location.Name = "college_textBox_Location";
            this.college_textBox_Location.Size = new System.Drawing.Size(228, 22);
            this.college_textBox_Location.TabIndex = 71;
            // 
            // userBtn_Reset
            // 
            this.userBtn_Reset.Location = new System.Drawing.Point(136, 333);
            this.userBtn_Reset.Name = "userBtn_Reset";
            this.userBtn_Reset.Size = new System.Drawing.Size(228, 23);
            this.userBtn_Reset.TabIndex = 70;
            this.userBtn_Reset.Text = "Reset";
            this.userBtn_Reset.UseVisualStyleBackColor = true;
            this.userBtn_Reset.Click += new System.EventHandler(this.userBtn_Reset_Click);
            // 
            // college_textBox_Email
            // 
            this.college_textBox_Email.Location = new System.Drawing.Point(137, 165);
            this.college_textBox_Email.Name = "college_textBox_Email";
            this.college_textBox_Email.Size = new System.Drawing.Size(228, 22);
            this.college_textBox_Email.TabIndex = 69;
            // 
            // college_textBox_Name
            // 
            this.college_textBox_Name.Location = new System.Drawing.Point(136, 57);
            this.college_textBox_Name.Name = "college_textBox_Name";
            this.college_textBox_Name.Size = new System.Drawing.Size(228, 22);
            this.college_textBox_Name.TabIndex = 67;
            // 
            // college_textBox_ID
            // 
            this.college_textBox_ID.Location = new System.Drawing.Point(136, 21);
            this.college_textBox_ID.Name = "college_textBox_ID";
            this.college_textBox_ID.Size = new System.Drawing.Size(100, 22);
            this.college_textBox_ID.TabIndex = 66;
            // 
            // college_Email
            // 
            this.college_Email.AutoSize = true;
            this.college_Email.Location = new System.Drawing.Point(72, 168);
            this.college_Email.Name = "college_Email";
            this.college_Email.Size = new System.Drawing.Size(35, 12);
            this.college_Email.TabIndex = 64;
            this.college_Email.Text = "Email:";
            // 
            // college_Phone
            // 
            this.college_Phone.AutoSize = true;
            this.college_Phone.Location = new System.Drawing.Point(70, 132);
            this.college_Phone.Name = "college_Phone";
            this.college_Phone.Size = new System.Drawing.Size(37, 12);
            this.college_Phone.TabIndex = 63;
            this.college_Phone.Text = "Phone:";
            // 
            // college_Location
            // 
            this.college_Location.AutoSize = true;
            this.college_Location.Location = new System.Drawing.Point(58, 96);
            this.college_Location.Name = "college_Location";
            this.college_Location.Size = new System.Drawing.Size(49, 12);
            this.college_Location.TabIndex = 62;
            this.college_Location.Text = "Location:";
            // 
            // college_Name
            // 
            this.college_Name.AutoSize = true;
            this.college_Name.Location = new System.Drawing.Point(33, 60);
            this.college_Name.Name = "college_Name";
            this.college_Name.Size = new System.Drawing.Size(74, 12);
            this.college_Name.TabIndex = 61;
            this.college_Name.Text = "College Name:";
            // 
            // college_ID
            // 
            this.college_ID.AutoSize = true;
            this.college_ID.Location = new System.Drawing.Point(48, 24);
            this.college_ID.Name = "college_ID";
            this.college_ID.Size = new System.Drawing.Size(59, 12);
            this.college_ID.TabIndex = 60;
            this.college_ID.Text = "College ID:";
            this.college_ID.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // UserControl_College
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.Controls.Add(this.college_textBox_Phone);
            this.Controls.Add(this.college_textBox_Location);
            this.Controls.Add(this.userBtn_Reset);
            this.Controls.Add(this.college_textBox_Email);
            this.Controls.Add(this.college_textBox_Name);
            this.Controls.Add(this.college_textBox_ID);
            this.Controls.Add(this.college_Email);
            this.Controls.Add(this.college_Phone);
            this.Controls.Add(this.college_Location);
            this.Controls.Add(this.college_Name);
            this.Controls.Add(this.college_ID);
            this.Name = "UserControl_College";
            this.Size = new System.Drawing.Size(861, 523);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox college_textBox_Phone;
        private System.Windows.Forms.TextBox college_textBox_Location;
        private System.Windows.Forms.Button userBtn_Reset;
        private System.Windows.Forms.TextBox college_textBox_Email;
        private System.Windows.Forms.TextBox college_textBox_Name;
        private System.Windows.Forms.TextBox college_textBox_ID;
        private System.Windows.Forms.Label college_Email;
        private System.Windows.Forms.Label college_Phone;
        private System.Windows.Forms.Label college_Location;
        private System.Windows.Forms.Label college_Name;
        private System.Windows.Forms.Label college_ID;
    }
}
